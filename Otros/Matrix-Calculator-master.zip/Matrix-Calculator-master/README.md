# Matrix Calculator
A matrix calculator with GUI, supporting most of the functions in Jama.
## Demo
<img src="https://github.com/irsisyphus/pictures/raw/master/Matrix-Calculator/main.png" alt="matrix-calculator" align=center />
You may want to download and use it to save time when calculating determinant or doing decomposition.
